package com.novaiptv.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.Actions
import com.novaiptv.app.app
import com.novaiptv.app.data.*
import com.novaiptv.app.download.Downloads
import kotlinx.coroutines.launch
import java.util.Locale

private fun pct(d: DownloadEntity) = if (d.total > 0) (d.downloaded * 100 / d.total).toInt().coerceIn(0, 100) else 0

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
    else String.format(Locale.US, "%.1f MB", mb)
}

/* ───────────────────────── الرئيسية ───────────────────────── */

@Composable
fun HomeScreen(vm: MainVM, act: Actions, onNavigateTab: (Int) -> Unit = {}) {
    val cur by vm.current.collectAsState()
    val lists by vm.lists.collectAsState()
    val recent by vm.recent.collectAsState()
    val favs by vm.favorites.collectAsState()
    val favKeys by vm.favKeys.collectAsState()
    LaunchedEffect(cur?.id) {
        vm.ensure(Kind.LIVE)
        vm.ensure(Kind.MOVIE)
        vm.ensure(Kind.SERIES)
    }

    val cont = recent.filter { it.content.kind != Kind.LIVE && it.pos > 10_000 && (it.dur <= 0 || it.pos < it.dur - 20_000) }
    val watched = recent.take(20)
    val allMovies = lists[Kind.MOVIE]?.items.orEmpty()
    val allSeries = lists[Kind.SERIES]?.items.orEmpty()
    val allLive = lists[Kind.LIVE]?.items.orEmpty()

    val movies = remember(allMovies) { allMovies.take(25) }
    val topMovies = remember(allMovies) {
        allMovies.filter { (it.rating.toDoubleOrNull() ?: 0.0) >= 7.0 }
            .sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
            .take(20)
    }
    val series = remember(allSeries) { allSeries.take(25) }
    val heroItem = remember(topMovies, movies, series) {
        topMovies.firstOrNull { !it.poster.isNullOrBlank() }
            ?: movies.firstOrNull { !it.poster.isNullOrBlank() }
            ?: series.firstOrNull { !it.poster.isNullOrBlank() }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NOVA", style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold))
                        Surface(color = Accent.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                            Text("PRO", color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(Emerald))
                        Text(cur?.name ?: "متصل", color = TextDim, fontSize = 12.sp)
                    }
                }
                IconButton(
                    onClick = {
                        vm.ensure(Kind.LIVE, true)
                        vm.ensure(Kind.MOVIE, true)
                        vm.ensure(Kind.SERIES, true)
                    }
                ) { Icon(Icons.Rounded.Refresh, null, tint = TextDim) }
                FilledTonalIconButton(onClick = { act.servers() }) {
                    Icon(Icons.Rounded.Dns, null, tint = Accent2)
                }
            }
        }

        // شريط الإحصائيات السريع
        if (allLive.isNotEmpty() || allMovies.isNotEmpty() || allSeries.isNotEmpty()) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatBadge(
                        icon = Icons.Rounded.LiveTv,
                        label = "قناة مباشرة",
                        value = "${allLive.size}",
                        modifier = Modifier.weight(1f).clickable { onNavigateTab(1) }
                    )
                    StatBadge(
                        icon = Icons.Rounded.Movie,
                        label = "فيلم",
                        value = "${allMovies.size}",
                        modifier = Modifier.weight(1f).clickable { onNavigateTab(2) }
                    )
                    StatBadge(
                        icon = Icons.Rounded.Tv,
                        label = "مسلسل",
                        value = "${allSeries.size}",
                        modifier = Modifier.weight(1f).clickable { onNavigateTab(3) }
                    )
                }
            }
        }

        // البانر السينمائي المميز (Hero Banner)
        heroItem?.let { hero ->
            item {
                HeroBanner(
                    c = hero,
                    isFav = hero.key in favKeys,
                    onPlay = {
                        if (hero.kind == Kind.MOVIE) act.play(listOf(hero), 0)
                        else act.open(hero)
                    },
                    onDetail = { act.open(hero) },
                    onToggleFav = { vm.toggleFav(hero) }
                )
            }
        }

        if (cont.isNotEmpty()) {
            item { SectionTitle("تابع المشاهدة", cont.size) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cont) { h ->
                        PosterCard(
                            h.content,
                            Modifier.width(125.dp),
                            progress = if (h.dur > 0) (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) else null,
                            fav = h.content.key in favKeys
                        ) {
                            act.resume(h.content)
                        }
                    }
                }
            }
        }

        if (favs.isNotEmpty()) {
            item { SectionTitle("مفضلتي", favs.size) { onNavigateTab(4) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(favs) { c -> PosterCard(c, Modifier.width(114.dp), fav = true) { act.open(c) } }
                }
            }
        }

        if (topMovies.isNotEmpty()) {
            item { SectionTitle("الأعلى تقييماً ⭐", topMovies.size) { onNavigateTab(2) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(topMovies) { c -> PosterCard(c, Modifier.width(114.dp), fav = c.key in favKeys) { act.open(c) } }
                }
            }
        }

        if (movies.isNotEmpty()) {
            item { SectionTitle("أحدث الأفلام", allMovies.size) { onNavigateTab(2) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(movies) { c -> PosterCard(c, Modifier.width(114.dp), fav = c.key in favKeys) { act.open(c) } }
                }
            }
        }

        if (series.isNotEmpty()) {
            item { SectionTitle("المسلسلات المميزة", allSeries.size) { onNavigateTab(3) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(series) { c -> PosterCard(c, Modifier.width(114.dp), fav = c.key in favKeys) { act.open(c) } }
                }
            }
        }

        if (watched.isNotEmpty()) {
            item { SectionTitle("شوهد مؤخراً") { onNavigateTab(4) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(watched) { h -> PosterCard(h.content, Modifier.width(110.dp), fav = h.content.key in favKeys) { act.resume(h.content) } }
                }
            }
        }

        val st = lists[Kind.MOVIE]
        val homeErr = st?.error
        if (st?.loading == true && movies.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) } }
        }
        if (homeErr != null && movies.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(homeErr, color = TextDim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { vm.ensure(Kind.LIVE, true); vm.ensure(Kind.MOVIE, true); vm.ensure(Kind.SERIES, true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) { Text("إعادة المحاولة") }
                }
            }
        }
    }
}

/* ───────────────────────── البث المباشر / الأفلام / المسلسلات ───────────────────────── */

@Composable
fun BrowseScreen(vm: MainVM, kind: Kind, title: String, act: Actions) {
    val cur by vm.current.collectAsState()
    val st = vm.lists.collectAsState().value[kind]
    val favKeys by vm.favKeys.collectAsState()
    LaunchedEffect(cur?.id) { vm.ensure(kind) }

    var query by rememberSaveable(kind.name) { mutableStateOf("") }
    var group by rememberSaveable(kind.name) { mutableStateOf<String?>(null) }
    var sortMode by rememberSaveable(kind.name) { mutableIntStateOf(0) } // 0=الافتراضي, 1=أبجدي, 2=التقييم, 3=المفضلة
    var liveGrid by rememberSaveable(kind.name) { mutableStateOf(false) }
    var showGroupsSheet by remember { mutableStateOf(false) }

    val all = st?.items.orEmpty()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, cur?.name, count = all.size, onRefresh = { vm.ensure(kind, true) }, onServers = { act.servers() })
        SearchField(query) { query = it }

        val err = st?.error
        if (st == null || st.loading) Loading()
        else if (err != null) ErrorBox(err) { vm.ensure(kind, true) }
        else {
            val groups = remember(all) {
                all.groupingBy { it.group }.eachCount().entries
                    .filter { it.key.isNotBlank() }
                    .sortedByDescending { it.value }
                    .map { it.key to it.value }
            }

            if (groups.isNotEmpty()) {
                GroupChips(
                    groups = groups,
                    selected = group,
                    onSelect = { group = it },
                    onOpenAllDialog = { showGroupsSheet = true }
                )
            }

            // شريط الفرز وتغيير طريقة العرض
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val sorts = if (kind == Kind.LIVE) listOf("الافتراضي", "أبجدي أ-ي", "المفضلة أولاً")
                else listOf("الأحدث", "الأعلى تقييماً ⭐", "أبجدي أ-ي")

                sorts.forEachIndexed { idx, label ->
                    FilterChip(
                        selected = sortMode == idx,
                        onClick = { sortMode = idx },
                        label = { Text(label, fontSize = 11.sp) },
                        shape = RoundedCornerShape(10.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                if (kind == Kind.LIVE) {
                    IconButton(onClick = { liveGrid = !liveGrid }, modifier = Modifier.size(34.dp)) {
                        Icon(
                            if (liveGrid) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                            contentDescription = "تبديل العرض",
                            tint = Accent2
                        )
                    }
                }
            }

            val filtered = remember(all, group, query, sortMode, favKeys) {
                val baseList = all.filter {
                    (group == null || it.group == group) &&
                        (query.isBlank() || it.title.contains(query, true) || it.group.contains(query, true))
                }
                when (kind) {
                    Kind.LIVE -> when (sortMode) {
                        1 -> baseList.sortedBy { it.title.lowercase() }
                        2 -> baseList.sortedByDescending { it.key in favKeys }
                        else -> baseList
                    }
                    else -> when (sortMode) {
                        1 -> baseList.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
                        2 -> baseList.sortedBy { it.title.lowercase() }
                        else -> baseList
                    }
                }
            }

            if (filtered.isEmpty()) EmptyBox("لا توجد نتائج مطابقة للبحث")
            else if (kind == Kind.LIVE && !liveGrid) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)) {
                    itemsIndexed(filtered) { i, c ->
                        val fav = c.key in favKeys
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { act.play(filtered, i) },
                            color = Surface1,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Poster(c.poster, c.title, Modifier.size(52.dp), fit = true)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                    if (c.group.isNotBlank()) Text(c.group, maxLines = 1, color = TextDim, fontSize = 12.sp)
                                }
                                IconButton(onClick = { vm.toggleFav(c) }) {
                                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else TextDim)
                                }
                            }
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(112.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(filtered) { i, c ->
                        PosterCard(c, fav = c.key in favKeys) {
                            if (kind == Kind.LIVE) act.play(filtered, i) else act.open(c)
                        }
                    }
                }
            }

            if (showGroupsSheet) {
                CategorySearchDialog(
                    groups = groups,
                    selected = group,
                    totalCount = all.size,
                    onSelect = { group = it; showGroupsSheet = false },
                    onDismiss = { showGroupsSheet = false }
                )
            }
        }
    }
}

@Composable
private fun CategorySearchDialog(
    groups: List<Pair<String, Int>>,
    selected: String?,
    totalCount: Int,
    onSelect: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    var catQuery by remember { mutableStateOf("") }
    val filteredGroups = remember(groups, catQuery) {
        if (catQuery.isBlank()) groups else groups.filter { it.first.contains(catQuery, true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("اختر القسم (${groups.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                OutlinedTextField(
                    value = catQuery,
                    onValueChange = { catQuery = it },
                    singleLine = true,
                    placeholder = { Text("ابحث في الأقسام…", fontSize = 13.sp, color = TextDim) },
                    leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Accent2) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    item {
                        ListItem(
                            headlineContent = { Text("كل الأقسام", fontWeight = FontWeight.Bold) },
                            trailingContent = { Text("$totalCount", color = Accent2) },
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onSelect(null) },
                            colors = ListItemDefaults.colors(containerColor = if (selected == null) Accent.copy(alpha = 0.25f) else Color.Transparent)
                        )
                    }
                    items(filteredGroups) { (g, cnt) ->
                        ListItem(
                            headlineContent = { Text(g, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { Text("$cnt", color = TextDim, fontSize = 12.sp) },
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onSelect(g) },
                            colors = ListItemDefaults.colors(containerColor = if (selected == g) Accent.copy(alpha = 0.25f) else Color.Transparent)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}

/* ───────────────────────── مكتبتي: المفضلة / السجل / التحميلات ───────────────────────── */

@Composable
fun LibraryScreen(vm: MainVM, act: Actions) {
    val favs by vm.favorites.collectAsState()
    val recent by vm.recent.collectAsState()
    val dls by vm.downloads.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("مكتبتي", null, null, null) { act.servers() }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val labels = listOf(
                "المفضلة (${favs.size})",
                "السجل (${recent.size})",
                "التحميلات (${dls.size})"
            )
            labels.forEachIndexed { i, t ->
                FilterChip(
                    selected = tab == i,
                    onClick = { tab = i },
                    label = { Text(t, fontSize = 12.sp) },
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> if (favs.isEmpty()) EmptyBox("لا توجد عناصر في المفضلة بعد") else {
                val live = favs.filter { it.kind == Kind.LIVE }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(112.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(favs) { c ->
                        PosterCard(c, fav = true) {
                            if (c.kind == Kind.LIVE) act.play(live, live.indexOf(c).coerceAtLeast(0)) else act.open(c)
                        }
                    }
                }
            }
            1 -> if (recent.isEmpty()) EmptyBox("لم تشاهد شيئاً بعد") else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { vm.clearHistory() }) {
                            Icon(Icons.Rounded.DeleteSweep, null, tint = Heart, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("مسح السجل بالكامل", color = Heart)
                        }
                    }
                }
                items(recent) { h ->
                    Surface(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { act.resume(h.content) },
                        color = Surface1
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Poster(h.content.poster, h.content.title, Modifier.size(width = 56.dp, height = 78.dp), fit = h.content.kind == Kind.LIVE)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.content.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                if (h.content.group.isNotBlank()) Text(h.content.group, color = TextDim, fontSize = 11.sp, maxLines = 1)
                                if (h.content.kind != Kind.LIVE && h.dur > 0) {
                                    Spacer(Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) },
                                        color = Accent2,
                                        trackColor = Surface2,
                                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                                    )
                                }
                            }
                            IconButton(onClick = { vm.removeHistory(h.content.key) }) { Icon(Icons.Rounded.Close, null, tint = TextDim) }
                        }
                    }
                }
            }
            else -> if (dls.isEmpty()) EmptyBox("لا توجد تحميلات حالياً. افتح أي فيلم أو مسلسل واضغط على زر التحميل") else {
                val done = dls.filter { it.status == "DONE" }
                    .map { contentFromJson(it.json) }
                    .sortedWith(compareBy({ it.seriesId ?: it.title }, { it.season }, { it.episode }))
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(dls) { d ->
                        val c = contentFromJson(d.json)
                        Surface(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 5.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(enabled = d.status == "DONE") {
                                    act.play(done, done.indexOfFirst { it.key == c.key }.coerceAtLeast(0))
                                },
                            color = Surface1
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Poster(c.poster, c.title, Modifier.size(width = 58.dp, height = 82.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(4.dp))
                                    when (d.status) {
                                        "DONE" -> {
                                            Text(
                                                "مكتمل (${formatBytes(d.total)}) · جاهز للمشاهدة بدون إنترنت",
                                                color = Emerald,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        "FAILED" -> Text(d.error.ifBlank { "فشل التحميل" }, color = Heart, fontSize = 12.sp, maxLines = 2)
                                        "QUEUED" -> Text("في طابور الانتظار…", color = Gold, fontSize = 12.sp)
                                        else -> {
                                            val sizeInfo = if (d.total > 0) "${formatBytes(d.downloaded)} / ${formatBytes(d.total)} (${pct(d)}%)"
                                            else formatBytes(d.downloaded)
                                            Text("جارٍ التحميل: $sizeInfo", color = Accent2, fontSize = 12.sp)
                                            Spacer(Modifier.height(6.dp))
                                            if (d.total > 0) {
                                                LinearProgressIndicator(
                                                    progress = { pct(d) / 100f },
                                                    color = Accent,
                                                    trackColor = Surface2,
                                                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                                                )
                                            } else {
                                                LinearProgressIndicator(
                                                    color = Accent,
                                                    trackColor = Surface2,
                                                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                                                )
                                            }
                                        }
                                    }
                                }
                                if (d.status == "DONE") {
                                    IconButton(onClick = { act.play(done, done.indexOfFirst { it.key == c.key }.coerceAtLeast(0)) }) {
                                        Icon(Icons.Rounded.PlayCircleFilled, null, tint = Accent2, modifier = Modifier.size(28.dp))
                                    }
                                }
                                if (d.status == "FAILED") {
                                    IconButton(onClick = { vm.retryDownload(d) }) {
                                        Icon(Icons.Rounded.Refresh, null, tint = Accent2)
                                    }
                                }
                                IconButton(onClick = { vm.removeDownload(d) }) {
                                    Icon(Icons.Rounded.Delete, null, tint = TextDim)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ───────────────────────── التفاصيل: فيلم أو مسلسل ───────────────────────── */

@Composable
fun DetailScreen(vm: MainVM, act: Actions, onBack: () -> Unit) {
    val c = vm.detail
    if (c == null) { LaunchedEffect(Unit) { onBack() }; return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val eps by vm.episodes.collectAsState()
    val favKeys by vm.favKeys.collectAsState()
    val dls by vm.downloads.collectAsState()
    val recent by vm.recent.collectAsState()
    val isSeries = c.kind == Kind.SERIES
    val dlMap = remember(dls) { dls.associateBy { it.contentKey } }
    val hMap = remember(recent) { recent.associateBy { it.content.key } }
    val list = eps.items
    val seasons = remember(list) { list.map { it.season }.distinct().sorted() }
    var season by rememberSaveable(c.key) { mutableIntStateOf(-1) }
    val curSeason = if (season in seasons) season else (seasons.firstOrNull() ?: 0)
    val inSeason = remember(list, curSeason) { list.filter { it.season == curSeason } }

    // تشغيل تلقائي عند الاستكمال من "تابع المشاهدة"
    LaunchedEffect(list) {
        val p = vm.pendingPlay
        if (p != null && list.isNotEmpty()) {
            vm.pendingPlay = null
            val i = list.indexOfFirst { it.key == p }
            if (i >= 0) act.play(list, i)
        }
    }

    val lastEp = recent.firstOrNull { it.content.kind == Kind.EPISODE && it.content.seriesId == c.seriesId }?.content

    LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Box(Modifier.fillMaxWidth()) {
                // خلفية سينمائية ممتدة
                if (!c.poster.isNullOrBlank()) {
                    AsyncImage(
                        model = c.poster,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(260.dp)
                    )
                } else {
                    Box(Modifier.fillMaxWidth().height(200.dp).background(Surface2))
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0x66070A12), Color(0xCC070A12), Bg)
                            )
                        )
                )

                Column(Modifier.fillMaxWidth()) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.padding(10.dp).clip(CircleShape).background(Color(0x77000000))
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White)
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.Bottom) {
                        Poster(c.poster, c.title, Modifier.width(125.dp).aspectRatio(0.68f))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.title, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 26.sp)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (c.group.isNotBlank()) {
                                    Surface(color = Surface2, shape = RoundedCornerShape(6.dp)) {
                                        Text(c.group, color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                                    }
                                }
                                if (c.rating.isNotBlank() && c.rating != "0") {
                                    Surface(color = Color(0x33FFB800), shape = RoundedCornerShape(6.dp)) {
                                        Text("★ ${c.rating.take(3)}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                                    }
                                }
                                if (c.ext.isNotBlank()) {
                                    Surface(color = Accent.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                                        Text(c.ext.uppercase(), color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                    }
                                }
                            }
                        }
                    }
                    if (c.plot.isNotBlank()) {
                        Text(
                            c.plot,
                            color = TextDim,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }

        // أزرار التحكم والتشغيل والتحميل
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            if (!isSeries) act.play(listOf(c), 0)
                            else if (list.isNotEmpty()) {
                                val i = if (lastEp != null) list.indexOfFirst { it.key == lastEp.key }.coerceAtLeast(0) else 0
                                act.play(list, i)
                            }
                        },
                        enabled = !isSeries || list.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (isSeries && lastEp != null || !isSeries && hMap[c.key] != null) "استكمال المشاهدة" else "تشغيل الآن",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedIconButton(
                        onClick = { vm.toggleFav(c) },
                        modifier = Modifier.size(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        val fav = c.key in favKeys
                        Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else Color.White)
                    }

                    // زر التشغيل في مشغل خارجي (VLC / MX Player)
                    OutlinedIconButton(
                        onClick = {
                            scope.launch {
                                try {
                                    val target = if (isSeries) (lastEp ?: list.firstOrNull()) else c
                                    if (target != null) {
                                        val playUri = Uri.parse(ctx.app.repo.playUrl(target))
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(playUri, "video/*")
                                            putExtra("title", target.display)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        ctx.startActivity(Intent.createChooser(intent, "تشغيل عبر مشغل خارجي"))
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(ctx, "تعذر فتح المشغل الخارجي", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.size(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Share, "مشغل خارجي", tint = Accent2)
                    }
                }

                if (!isSeries) {
                    val d = dlMap[c.key]
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        FilledTonalButton(
                            onClick = {
                                when (d?.status) {
                                    null -> vm.download(listOf(c))
                                    "FAILED" -> vm.retryDownload(d)
                                    "DONE" -> act.play(listOf(c), 0)
                                    else -> vm.removeDownload(d)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(46.dp)
                        ) {
                        Icon(
                            when (d?.status) {
                                "DONE" -> Icons.Rounded.DownloadDone
                                "RUNNING", "QUEUED" -> Icons.Rounded.Close
                                else -> Icons.Rounded.Download
                            },
                            null,
                            tint = if (d?.status == "DONE") Emerald else Accent2
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when (d?.status) {
                                null -> "تحميل الفيلم للمشاهدة بدون إنترنت"
                                "DONE" -> "تم التحميل (${formatBytes(d.total)}) — اضغط للتشغيل"
                                "FAILED" -> "فشل التحميل (${d.error.take(30)}) — اضغط للإعادة"
                                "QUEUED" -> "في الانتظار… (اضغط للإلغاء)"
                                else -> "جارٍ التحميل ${pct(d!!)}% (${formatBytes(d.downloaded)}) — اضغط للإلغاء"
                            },
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        }
                        OutlinedIconButton(
                            onClick = { Downloads.downloadWithSystemManager(ctx, c) },
                            modifier = Modifier.size(46.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.SaveAlt, "تحميل مباشر للهاتف", tint = Gold)
                        }
                    }
                }
            }
        }

        if (isSeries) {
            when {
                eps.loading -> item { Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) } }
                eps.error != null -> item {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(eps.error!!, color = TextDim, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { vm.loadEpisodes(c) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
                    }
                }
                list.isEmpty() -> item { Text("لا توجد حلقات متاحة", color = TextDim, modifier = Modifier.padding(16.dp)) }
                else -> {
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasons) { s ->
                                FilterChip(
                                    selected = s == curSeason,
                                    onClick = { season = s },
                                    label = { Text("الموسم $s") },
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }
                    }
                    item {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = { vm.download(inSeason) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Rounded.Download, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("تحميل الموسم (${inSeason.size})", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { vm.download(list) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("تحميل المسلسل كاملاً (${list.size})", fontSize = 12.sp)
                            }
                        }
                    }
                    items(inSeason) { e ->
                        val d = dlMap[e.key]
                        val h = hMap[e.key]
                        Surface(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { act.play(list, list.indexOfFirst { it.key == e.key }.coerceAtLeast(0)) },
                            color = Surface1
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Poster(e.poster, e.title, Modifier.size(width = 96.dp, height = 58.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("${e.episode}. ${e.title}", maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    if (d != null && d.status != "DONE") {
                                        Text(
                                            when (d.status) {
                                                "FAILED" -> "فشل: ${d.error.take(25)}"
                                                "QUEUED" -> "في الانتظار…"
                                                else -> "جارٍ التحميل ${pct(d)}%"
                                            },
                                            fontSize = 11.sp,
                                            color = if (d.status == "FAILED") Heart else Accent2
                                        )
                                    }
                                    if (h != null && h.dur > 0) {
                                        Spacer(Modifier.height(5.dp))
                                        LinearProgressIndicator(
                                            progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) },
                                            color = Accent2,
                                            trackColor = Surface2,
                                            modifier = Modifier.fillMaxWidth().height(3.dp)
                                        )
                                    }
                                }
                                when (d?.status) {
                                    null -> IconButton(onClick = { vm.download(listOf(e)) }) {
                                        Icon(Icons.Rounded.Download, null, tint = Accent2)
                                    }
                                    "DONE" -> Icon(Icons.Rounded.DownloadDone, null, tint = Emerald, modifier = Modifier.padding(12.dp))
                                    "FAILED" -> IconButton(onClick = { vm.retryDownload(d) }) {
                                        Icon(Icons.Rounded.Refresh, null, tint = Heart)
                                    }
                                    else -> IconButton(onClick = { vm.removeDownload(d) }) {
                                        CircularProgressIndicator(
                                            progress = { pct(d) / 100f },
                                            modifier = Modifier.size(24.dp),
                                            strokeWidth = 2.5.dp,
                                            color = Accent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
