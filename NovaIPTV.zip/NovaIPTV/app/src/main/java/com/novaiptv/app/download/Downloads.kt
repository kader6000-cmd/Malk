package com.novaiptv.app.download

import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.novaiptv.app.app
import com.novaiptv.app.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object Downloads {
    private const val QUEUE = "dl-queue"
    private val mutex = Mutex()
    private var activeJob: Job? = null

    /** إضافة حلقة/فيلم/قائمة كاملة إلى طابور التحميل والبدء الفوري */
    suspend fun enqueue(ctx: Context, items: List<Content>) {
        val app = ctx.app
        val dao = app.db.downloads()
        var added = 0
        for (c in items) {
            if (c.kind == Kind.LIVE) continue
            val ex = dao.get(c.key)
            if (ex != null && ex.status == "DONE" && File(ex.filePath).exists()) continue
            if (ex != null && (ex.status == "QUEUED" || ex.status == "RUNNING")) continue
            dao.upsert(
                DownloadEntity(
                    contentKey = c.key,
                    serverId = c.serverId,
                    json = c.toJson(),
                    title = c.display,
                    filePath = ex?.filePath ?: "",
                    status = "QUEUED",
                    downloaded = ex?.downloaded ?: 0,
                    total = ex?.total ?: 0,
                    updatedAt = System.currentTimeMillis(),
                    error = ""
                )
            )
            added++
        }
        if (added > 0) {
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    ctx,
                    if (added == 1) "بدأ التحميل فوراً — راجع تبويب مكتبتي" else "تمت إضافة $added عناصر إلى طابور التحميل",
                    Toast.LENGTH_SHORT
                ).show()
            }
            start(app)
        }
    }

    fun start(ctx: Context) {
        val app = ctx.app
        // تشغيل فوري عبر Coroutine داخل التطبيق لضمان عدم تأخر WorkManager
        if (activeJob?.isActive != true) {
            activeJob = app.appScope.launch {
                runQueue(app)
            }
        }
        // جدولة WorkManager كاحتياطي عند إغلاق التطبيق
        runCatching {
            val req = OneTimeWorkRequestBuilder<DownloadWorker>().build()
            WorkManager.getInstance(app).enqueueUniqueWork(QUEUE, ExistingWorkPolicy.KEEP, req)
        }
    }

    suspend fun retry(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().upsert(d.copy(status = "QUEUED", error = "", updatedAt = System.currentTimeMillis()))
        start(ctx)
    }

    suspend fun remove(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().remove(d.contentKey)
        withContext(Dispatchers.IO) { if (d.filePath.isNotBlank()) File(d.filePath).delete() }
    }

    /** تحميل مباشر عبر مدير التحميلات الرسمي لنظام أندرويد (System DownloadManager) كخيار إضافي */
    fun downloadWithSystemManager(ctx: Context, c: Content) {
        val app = ctx.app
        app.appScope.launch {
            try {
                val server = app.db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")
                val updated = if (c.kind == Kind.MOVIE && server.type == ServerType.XTREAM.name) {
                    app.repo.movieDetails(server, c)
                } else c
                var rawUrl = app.repo.remoteUrl(updated)
                if (rawUrl.startsWith("http://", true) && rawUrl.contains(":80/")) {
                    rawUrl = rawUrl.replaceFirst(":80/", "/")
                }
                val ua = server.userAgent.ifBlank { DEFAULT_UA }
                val finalUrl = resolveRedirectUrl(app.http.client, rawUrl, ua)
                val ext = updated.ext.ifBlank {
                    finalUrl.substringBefore('?').substringAfterLast('.', "mp4").take(4).lowercase().ifBlank { "mp4" }
                }
                val cleanTitle = updated.display.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "Nova_Video" }
                val fileName = "$cleanTitle.$ext"

                val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val request = DownloadManager.Request(Uri.parse(finalUrl))
                    .addRequestHeader("User-Agent", ua)
                    .addRequestHeader("Accept", "*/*")
                    .setTitle(updated.display)
                    .setDescription("جاري التحميل عبر Nova IPTV...")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "NovaIPTV/$fileName")

                dm.enqueue(request)
                withContext(Dispatchers.Main) {
                    Toast.makeText(ctx, "بدأ التحميل في إشعارات الهاتف (Downloads/NovaIPTV)", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(ctx, "فشل بدء التحميل الخارجي: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    suspend fun runQueue(ctx: Context) {
        mutex.withLock {
            val dao = ctx.app.db.downloads()
            while (true) {
                val d = dao.nextPending() ?: break
                try {
                    processDownload(ctx, d)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (dao.get(d.contentKey) != null) {
                        dao.upsert(
                            d.copy(
                                status = "FAILED",
                                error = e.message ?: "فشل التحميل",
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        }
    }

    private fun resolveRedirectUrl(baseClient: OkHttpClient, initialUrl: String, ua: String): String {
        val noRedirectClient = baseClient.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
        var currentUrl = initialUrl
        var redirects = 0
        while (redirects < 10) {
            val req = Request.Builder()
                .url(currentUrl)
                .header("User-Agent", ua)
                .header("Accept", "*/*")
                .header("Range", "bytes=0-1")
                .build()
            val validLoc = runCatching {
                noRedirectClient.newCall(req).execute().use { resp ->
                    if (resp.code in listOf(301, 302, 303, 307, 308)) {
                        resp.header("Location")
                    } else null
                }
            }.getOrNull()
            if (validLoc.isNullOrBlank()) break
            currentUrl = if (validLoc.startsWith("http", true)) validLoc else {
                val origin = Regex("^(https?://[^/]+)").find(currentUrl)?.groupValues?.get(1) ?: ""
                if (validLoc.startsWith("/")) origin + validLoc else "$origin/$validLoc"
            }
            redirects++
        }
        return currentUrl
    }

    private fun openStreamWithRedirects(
        baseClient: OkHttpClient,
        initialUrl: String,
        userAgent: String,
        rangeStart: Long
    ): Pair<Response, Long> {
        val noRedirectClient = baseClient.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()

        val uas = listOf(
            userAgent.ifBlank { DEFAULT_UA },
            PLAYER_UA,
            "VLC/3.0.20 LibVLC/3.0.20",
            "IBOPlayer",
            DEFAULT_UA
        ).distinct()
        var lastError = "تعذر الاتصال بالسيرفر"

        for (ua in uas) {
            for (useRange in listOf(true, false)) {
                try {
                    var currentUrl = initialUrl
                    var redirects = 0
                    var cookieHeader: String? = null
                    while (redirects < 10) {
                        val reqBuilder = Request.Builder()
                            .url(currentUrl)
                            .header("User-Agent", ua)
                            .header("Accept", "*/*")
                            .header("Connection", "keep-alive")
                        if (!cookieHeader.isNullOrBlank()) {
                            reqBuilder.header("Cookie", cookieHeader)
                        }
                        if (useRange && rangeStart > 0) {
                            reqBuilder.header("Range", "bytes=$rangeStart-")
                        }

                        val resp = noRedirectClient.newCall(reqBuilder.build()).execute()
                        val code = resp.code

                        val setCookies = resp.headers("Set-Cookie")
                        if (setCookies.isNotEmpty()) {
                            cookieHeader = setCookies.joinToString("; ") { it.substringBefore(';') }
                        }

                        if (code in listOf(301, 302, 303, 307, 308)) {
                            val loc = resp.header("Location")
                            resp.close()
                            if (loc.isNullOrBlank()) break
                            currentUrl = if (loc.startsWith("http", true)) loc else {
                                val origin = Regex("^(https?://[^/]+)").find(currentUrl)?.groupValues?.get(1) ?: ""
                                if (loc.startsWith("/")) origin + loc else "$origin/$loc"
                            }
                            redirects++
                            continue
                        }

                        if (resp.isSuccessful) {
                            val ct = resp.header("Content-Type")?.lowercase() ?: ""
                            if (ct.contains("text/html") || ct.contains("application/json")) {
                                resp.close()
                                lastError = "السيرفر رفض التحميل المباشر ($ct)"
                                break
                            }
                            val actualOffset = if (code == 206 && useRange && rangeStart > 0) rangeStart else 0L
                            return resp to actualOffset
                        } else {
                            lastError = "HTTP $code"
                            resp.close()
                            break
                        }
                    }
                } catch (e: Exception) {
                    lastError = e.message ?: "خطأ في الشبكة"
                }
            }
        }
        throw IllegalStateException("تعذر التحميل من السيرفر ($lastError)")
    }

    private suspend fun processDownload(ctx: Context, d: DownloadEntity) {
        val app = ctx.app
        val dao = app.db.downloads()
        var c = contentFromJson(d.json)
        val server = app.db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")

        if (c.kind == Kind.MOVIE && server.type == ServerType.XTREAM.name) {
            c = app.repo.movieDetails(server, c)
        }

        var url = app.repo.remoteUrl(c)
        if (url.startsWith("http://", true) && url.contains(":80/")) {
            url = url.replaceFirst(":80/", "/")
        }

        if (url.contains(".m3u8", true)) {
            throw IllegalStateException("هذا المحتوى يعمل ببث متقطع (HLS) ولا يدعم التحميل المباشر")
        }

        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "downloads").apply { mkdirs() }
        val baseFileName = c.key.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val initialExt = c.ext.ifBlank {
            url.substringBefore('?').substringAfterLast('.', "mp4").take(4).lowercase().ifBlank { "mp4" }
        }
        val file = File(dir, "$baseFileName.$initialExt")
        val existing = if (file.exists()) file.length() else 0L

        dao.upsert(d.copy(filePath = file.absolutePath, status = "RUNNING", error = "", updatedAt = System.currentTimeMillis()))
        notifyProgress(ctx, d.title, 0, true)

        withContext(Dispatchers.IO) {
            val (r, offset) = openStreamWithRedirects(
                baseClient = app.http.client,
                initialUrl = url,
                userAgent = server.userAgent.ifBlank { DEFAULT_UA },
                rangeStart = existing
            )
            r.use { resp ->
                val append = offset > 0L
                val body = resp.body ?: throw IllegalStateException("رد فارغ من السيرفر")
                val contentLength = body.contentLength()
                val total = if (contentLength > 0) contentLength + offset else 0L
                var done = offset
                var lastTick = 0L

                FileOutputStream(file, append).use { out ->
                    body.byteStream().use { ins ->
                        val buf = ByteArray(128 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 700) {
                                lastTick = now
                                if (dao.get(d.contentKey) == null) {
                                    out.close()
                                    file.delete()
                                    cancelNotification(ctx)
                                    return@withContext
                                }
                                dao.progress(d.contentKey, done, total, "RUNNING", now)
                                val p = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
                                notifyProgress(ctx, d.title, p, total <= 0)
                            }
                        }
                    }
                }
            }
        }

        if (dao.get(d.contentKey) == null) {
            cancelNotification(ctx)
            return
        }
        val size = file.length()
        if (size < 10_000L) {
            file.delete()
            cancelNotification(ctx)
            throw IllegalStateException("الملف المحمّل صغير جداً — السيرفر رفض التحميل")
        }

        runCatching { exportToPublicDownloads(ctx, file, c.display, initialExt) }
        dao.progress(d.contentKey, size, size, "DONE", System.currentTimeMillis())
        notifyComplete(ctx, d.title)
    }

    private fun exportToPublicDownloads(ctx: Context, srcFile: File, displayTitle: String, ext: String) {
        val cleanName = displayTitle.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { srcFile.nameWithoutExtension }
        val fileName = "$cleanName.$ext"
        val mime = when (ext.lowercase()) {
            "mkv" -> "video/x-matroska"
            "ts" -> "video/mp2t"
            else -> "video/mp4"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NovaIPTV")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(srcFile).use { ins -> ins.copyTo(out, 128 * 1024) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            val pubDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NovaIPTV").apply { mkdirs() }
            val dst = File(pubDir, fileName)
            srcFile.copyTo(dst, overwrite = true)
        }
    }

    private fun notifyProgress(ctx: Context, title: String, progress: Int, indeterminate: Boolean) {
        runCatching {
            val ch = "downloads"
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(NotificationChannel(ch, "التحميلات", NotificationManager.IMPORTANCE_LOW))
            val n = NotificationCompat.Builder(ctx, ch)
                .setContentTitle(if (indeterminate) "جارٍ التحميل…" else "جارٍ التحميل ($progress%)")
                .setContentText(title)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setProgress(100, progress, indeterminate)
                .setOngoing(true)
                .build()
            nm.notify(1001, n)
        }
    }

    private fun notifyComplete(ctx: Context, title: String) {
        runCatching {
            val ch = "downloads"
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(NotificationChannel(ch, "التحميلات", NotificationManager.IMPORTANCE_DEFAULT))
            val n = NotificationCompat.Builder(ctx, ch)
                .setContentTitle("اكتمل التحميل ✓")
                .setContentText(title)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .build()
            nm.notify(1002, n)
            nm.cancel(1001)
        }
    }

    private fun cancelNotification(ctx: Context) {
        runCatching {
            ctx.getSystemService(NotificationManager::class.java)?.cancel(1001)
        }
    }
}

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Downloads.runQueue(applicationContext)
        return Result.success()
    }
}
