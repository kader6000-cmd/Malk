package com.novaiptv.app.data

import android.content.Context
import android.net.Uri
import java.io.File

class Repository(private val ctx: Context, private val db: AppDb, private val http: Http) {
    private val providers = HashMap<Long, IptvProvider>()
    private val cache = HashMap<String, List<Content>>()

    private fun provider(s: ServerEntity): IptvProvider =
        providers.getOrPut(s.id) { Providers.create(ctx, s, http) }

    suspend fun load(s: ServerEntity, kind: Kind, force: Boolean = false): List<Content> {
        val k = "${s.id}:$kind"
        if (force) { providers.remove(s.id); cache.keys.removeAll { it.startsWith("${s.id}:") } }
        cache[k]?.let { return it }
        val list = provider(s).load(kind)
        cache[k] = list
        return list
    }

    suspend fun episodes(s: ServerEntity, series: Content): List<Content> = provider(s).episodes(series)

    suspend fun movieDetails(s: ServerEntity, movie: Content): Content = provider(s).movieDetails(movie)

    fun invalidate(serverId: Long) {
        providers.remove(serverId)
        cache.keys.removeAll { it.startsWith("$serverId:") }
    }

    suspend fun testServer(s: ServerEntity) = Providers.create(ctx, s, http).test()

    /** ملف التحميل المحلي إن وُجد (للتشغيل بدون إنترنت) */
    suspend fun localFile(key: String): File? {
        val d = db.downloads().get(key) ?: return null
        if (d.status != "DONE" || d.filePath.isBlank()) return null
        return File(d.filePath).takeIf { it.exists() && it.length() > 0 }
    }

    /** رابط التشغيل: ملف محلي إن كان محمّلاً، وإلا رابط السيرفر */
    suspend fun playUrl(c: Content): String {
        localFile(c.key)?.let { return Uri.fromFile(it).toString() }
        val s = db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")
        return if (c.resolve) provider(s).resolve(c) else c.url
    }

    /** رابط التحميل (دائماً من السيرفر) */
    suspend fun remoteUrl(c: Content): String {
        val s = db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")
        return if (c.resolve) provider(s).resolve(c) else c.url
    }
}
