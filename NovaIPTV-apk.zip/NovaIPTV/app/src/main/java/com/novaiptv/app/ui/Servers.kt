package com.novaiptv.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.data.ServerEntity
import com.novaiptv.app.data.ServerType
import com.novaiptv.app.data.cleanServerBaseUrl

/* ───────────────────────── قائمة السيرفرات ───────────────────────── */

@Composable
fun ServersScreen(vm: MainVM, onBack: () -> Unit, onEdit: (Long) -> Unit) {
    val servers by vm.servers.collectAsState()
    val cur by vm.current.collectAsState()
    var toDelete by remember { mutableStateOf<ServerEntity?>(null) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("السيرفرات", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { onEdit(0L) }, modifier = Modifier.padding(end = 8.dp)) {
                Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة سيرفر")
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(servers.orEmpty()) { s ->
                val selected = s.id == cur?.id
                Card(
                    modifier = Modifier.clickable { vm.select(s.id); onBack() },
                    colors = CardDefaults.cardColors(containerColor = if (selected) Accent.copy(alpha = 0.2f) else Surface1),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected, onClick = { vm.select(s.id); onBack() })
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold)
                            Text(
                                (ServerType.entries.firstOrNull { it.name == s.type }?.label ?: s.type) + " · " + s.url,
                                color = TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { onEdit(s.id) }) { Icon(Icons.Rounded.Edit, null) }
                        IconButton(onClick = { toDelete = s }) { Icon(Icons.Rounded.Delete, null, tint = Heart) }
                    }
                }
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف السيرفر؟") },
            text = { Text("سيتم حذف «${s.name}» مع مفضلته وسجل مشاهدته. التحميلات تبقى كما هي.") },
            confirmButton = { TextButton(onClick = { vm.deleteServer(s); toDelete = null }) { Text("حذف", color = Heart) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("إلغاء") } }
        )
    }
}

/* ───────────────────────── إضافة / تعديل سيرفر ───────────────────────── */

private fun normalizeServer(s: ServerEntity): ServerEntity {
    var x = s.copy(
        name = s.name.trim().ifBlank { "سيرفري" },
        url = s.url.trim(),
        username = s.username.trim(),
        password = s.password.trim()
    )
    // رابط get.php فيه username/password = Xtream في الحقيقة
    if (x.type == ServerType.M3U_URL.name && x.url.contains("get.php")) {
        val u = runCatching { Uri.parse(x.url) }.getOrNull()
        val user = u?.getQueryParameter("username")
        val pass = u?.getQueryParameter("password")
        if (!user.isNullOrBlank() && !pass.isNullOrBlank()) {
            x = x.copy(
                type = ServerType.XTREAM.name,
                url = cleanServerBaseUrl(x.url.substringBefore("/get.php")),
                username = user.trim(),
                password = pass.trim()
            )
        }
    } else if (x.type == ServerType.XTREAM.name) {
        x = x.copy(url = cleanServerBaseUrl(x.url))
    }
    return x
}

@Composable
fun ServerEditScreen(vm: MainVM, id: Long, firstRun: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val servers by vm.servers.collectAsState()
    val existing = remember(id, servers) { servers?.firstOrNull { it.id == id } }

    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var type by remember(existing) { mutableStateOf(existing?.type ?: ServerType.XTREAM.name) }
    var url by remember(existing) { mutableStateOf(existing?.url ?: "") }
    var user by remember(existing) { mutableStateOf(existing?.username ?: "") }
    var pass by remember(existing) { mutableStateOf(existing?.password ?: "") }
    var mac by remember(existing) { mutableStateOf(existing?.mac ?: "00:1A:79:") }
    var ua by remember(existing) { mutableStateOf(existing?.userAgent ?: "") }
    var liveExt by remember(existing) { mutableStateOf(existing?.liveExt ?: "m3u8") }
    var status by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var showAdv by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            url = uri.toString()
            if (name.isBlank()) name = "ملف M3U"
        }
    }

    fun build() = normalizeServer(
        ServerEntity(
            id = existing?.id ?: 0, name = name, type = type, url = url, username = user, password = pass,
            mac = mac.trim(), userAgent = ua.trim(), liveExt = liveExt
        )
    )

    Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(rememberScrollState()).imePadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!firstRun) IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text(if (firstRun) "أهلاً بك في NOVA PRO" else if (existing == null) "إضافة سيرفر" else "تعديل السيرفر", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (firstRun) Text("أضف أول سيرفر IPTV للبدء. يمكنك إضافة أي عدد من السيرفرات بأي نوع والتبديل بينها بسهولة.", color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        Spacer(Modifier.height(12.dp))

        Text("نوع السيرفر", color = TextDim, fontSize = 12.sp)
        FlowChips(ServerType.entries.map { it.name to it.label }, type) { type = it; status = null }
        Spacer(Modifier.height(10.dp))

        Field("اسم السيرفر", name) { name = it }
        when (type) {
            ServerType.XTREAM.name -> {
                Field("رابط السيرفر (مثال: http://tv.nv2.info:80)", url, KeyboardType.Uri) { url = it }
                Field("اسم المستخدم", user) { user = it }
                Field("كلمة المرور", pass, password = true) { pass = it }
            }
            ServerType.M3U_URL.name -> {
                Field("رابط قائمة M3U / M3U8", url, KeyboardType.Uri) { url = it }
                Text("يمكنك لصق رابط get.php من مزوّد Xtream وسيتم التعرف عليه تلقائياً.", color = TextDim, fontSize = 12.sp)
            }
            ServerType.M3U_FILE.name -> {
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(8.dp))
                    Text(if (url.isBlank()) "اختيار ملف M3U من الجهاز" else "تم اختيار ملف — اضغط للتغيير")
                }
            }
            ServerType.STALKER.name -> {
                Field("رابط البوابة (مثال: http://host:8080/c/)", url, KeyboardType.Uri) { url = it }
                Field("عنوان MAC (مثال: 00:1A:79:XX:XX:XX)", mac) { mac = it }
                Text("دعم Stalker تجريبي وقد يختلف من بوابة لأخرى.", color = TextDim, fontSize = 12.sp)
            }
        }

        TextButton(onClick = { showAdv = !showAdv }) { Text(if (showAdv) "إخفاء الخيارات المتقدمة" else "خيارات متقدمة") }
        if (showAdv) {
            Field("User-Agent (اختياري — الافتراضي IPTVSmartersPlayer)", ua) { ua = it }
            if (type == ServerType.XTREAM.name) {
                Text("صيغة البث المباشر", color = TextDim, fontSize = 12.sp)
                FlowChips(listOf("m3u8" to "m3u8 (HLS)", "ts" to "ts (MPEG-TS)"), liveExt) { liveExt = it }
            }
        }

        status?.let {
            Text(it, color = if (it.startsWith("✓")) Emerald else Heart, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                enabled = !testing && url.isNotBlank(), modifier = Modifier.weight(1f),
                onClick = {
                    testing = true; status = null
                    vm.test(build()) { err -> testing = false; status = err?.let { "✗ $it" } ?: "✓ الاتصال ناجح" }
                }
            ) { if (testing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("اختبار الاتصال") }
            Button(
                enabled = url.isNotBlank(), modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                onClick = { vm.saveServer(build()); onClose() }
            ) { Text("حفظ") }
        }
    }
}

@Composable
private fun Field(label: String, value: String, keyboard: KeyboardType = KeyboardType.Text, password: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label, fontSize = 13.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, label) -> FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(label) }) }
    }
}
