package com.novaiptv.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.novaiptv.app.data.Content
import com.novaiptv.app.data.Kind
import com.novaiptv.app.player.PlayQueue
import com.novaiptv.app.player.PlayerActivity
import com.novaiptv.app.ui.*

class MainActivity : ComponentActivity() {
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            NovaTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { AppRoot() }
            }
        }
    }
}

/** كل إجراءات التنقل والتشغيل في مكان واحد */
class Actions(private val vm: MainVM, private val nav: NavController, private val ctx: Context) {
    fun play(items: List<Content>, index: Int) {
        if (items.isEmpty()) return
        PlayQueue.set(items, index)
        ctx.startActivity(Intent(ctx, PlayerActivity::class.java))
    }

    fun open(c: Content) {
        when (c.kind) {
            Kind.LIVE -> play(listOf(c), 0)
            Kind.EPISODE -> resume(c)
            else -> { vm.openDetail(c); nav.navigate("detail") }
        }
    }

    /** استكمال: الحلقة تفتح صفحة المسلسل وتشغّل تلقائياً مع قائمة الحلقات كاملة */
    fun resume(c: Content) {
        if (c.kind == Kind.EPISODE) {
            vm.pendingPlay = c.key
            vm.openDetail(c.asSeries())
            nav.navigate("detail")
        } else play(listOf(c), 0)
    }

    fun servers() { nav.navigate("servers") }
}

@Composable
fun AppRoot() {
    val vm: MainVM = viewModel()
    val servers by vm.servers.collectAsState()
    Surface(Modifier.fillMaxSize().statusBarsPadding(), color = Bg) {
        val list = servers
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
            list.isEmpty() -> ServerEditScreen(vm, 0L, true) { }
            else -> NavRoot(vm)
        }
    }
}

@Composable
private fun NavRoot(vm: MainVM) {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val act = remember(nav) { Actions(vm, nav, ctx) }
    NavHost(nav, startDestination = "main") {
        composable("main") { MainScreen(vm, act) }
        composable("detail") { DetailScreen(vm, act) { nav.popBackStack() } }
        composable("servers") { ServersScreen(vm, { nav.popBackStack() }, { id -> nav.navigate("edit/$id") }) }
        composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            ServerEditScreen(vm, e.arguments?.getLong("id") ?: 0L, false) { nav.popBackStack() }
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private fun isOnline(c: Context): Boolean {
    val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
    val n = cm.activeNetwork ?: return false
    val cap = cm.getNetworkCapabilities(n) ?: return false
    return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

@Composable
private fun MainScreen(vm: MainVM, act: Actions) {
    val ctx = LocalContext.current
    val dls by vm.downloads.collectAsState()
    val activeDownloads = remember(dls) { dls.count { it.status == "RUNNING" || it.status == "QUEUED" } }

    // بدون إنترنت: ابدأ من المكتبة لتشغيل التحميلات
    var tab by rememberSaveable { mutableIntStateOf(if (isOnline(ctx)) 0 else 4) }
    val tabs = remember {
        listOf(
            Tab("الرئيسية", Icons.Rounded.Home),
            Tab("مباشر", Icons.Rounded.LiveTv),
            Tab("أفلام", Icons.Rounded.Movie),
            Tab("مسلسلات", Icons.Rounded.Tv),
            Tab("مكتبتي", Icons.Rounded.VideoLibrary)
        )
    }
    Scaffold(
        containerColor = Bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = {
                            if (i == 4 && activeDownloads > 0) {
                                BadgedBox(badge = { Badge(containerColor = Accent2) { Text("$activeDownloads") } }) {
                                    Icon(t.icon, null)
                                }
                            } else {
                                Icon(t.icon, null)
                            }
                        },
                        label = { Text(t.label, fontSize = 11.sp, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent2,
                            selectedTextColor = Accent2,
                            indicatorColor = Accent.copy(alpha = 0.25f)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(vm, act) { targetTab -> tab = targetTab }
                1 -> BrowseScreen(vm, Kind.LIVE, "البث المباشر", act)
                2 -> BrowseScreen(vm, Kind.MOVIE, "الأفلام", act)
                3 -> BrowseScreen(vm, Kind.SERIES, "المسلسلات", act)
                else -> LibraryScreen(vm, act)
            }
        }
    }
}
