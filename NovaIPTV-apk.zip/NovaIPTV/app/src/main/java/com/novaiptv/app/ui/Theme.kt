package com.novaiptv.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF070A12)
val Surface1 = Color(0xFF111625)
val Surface2 = Color(0xFF1A2238)
val SurfaceGlass = Color(0xCC151C2E)
val BorderSubtle = Color(0x26FFFFFF)
val Accent = Color(0xFF7C5CFF)
val Accent2 = Color(0xFF00D1FF)
val Gold = Color(0xFFFFB800)
val Emerald = Color(0xFF10B981)
val TextDim = Color(0xFF94A3B8)
val Heart = Color(0xFFFF4D6D)
val AccentBrush = Brush.linearGradient(listOf(Accent, Accent2))
val HeroGradient = Brush.verticalGradient(
    listOf(Color(0x33070A12), Color(0x99070A12), Bg)
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Accent2, background = Bg, surface = Surface1,
            surfaceVariant = Surface2, surfaceContainer = Surface1, surfaceContainerHigh = Surface2,
            onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = TextDim,
            primaryContainer = Surface2, onPrimaryContainer = Color.White,
            secondaryContainer = Accent.copy(alpha = 0.25f), onSecondaryContainer = Color.White
        ),
        content = content
    )
}
