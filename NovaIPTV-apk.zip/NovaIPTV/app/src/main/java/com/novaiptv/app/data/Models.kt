package com.novaiptv.app.data

import org.json.JSONArray
import org.json.JSONObject

enum class Kind { LIVE, MOVIE, SERIES, EPISODE }

/** أنواع السيرفرات المدعومة. لإضافة نوع جديد: أضف قيمة هنا ثم Provider جديد في Providers.kt */
enum class ServerType(val label: String) {
    XTREAM("Xtream Codes"),
    M3U_URL("رابط M3U"),
    M3U_FILE("ملف M3U"),
    STALKER("Stalker / MAG")
}

data class Content(
    val key: String,
    val serverId: Long,
    val kind: Kind,
    val title: String,
    val poster: String? = null,
    val group: String = "",
    val url: String = "",
    val seriesId: String? = null,
    val seriesTitle: String = "",
    val season: Int = 0,
    val episode: Int = 0,
    val rating: String = "",
    val plot: String = "",
    val ext: String = "",
    val resolve: Boolean = false
) {
    val display: String
        get() = if (kind == Kind.EPISODE) "${seriesTitle.ifBlank { group }} · م$season ح$episode" else title

    fun asSeries() = Content(
        key = "$serverId:S:$seriesId", serverId = serverId, kind = Kind.SERIES,
        title = seriesTitle.ifBlank { title }, poster = poster, seriesId = seriesId
    )
}

fun Content.toJson(): String = JSONObject().apply {
    put("key", key); put("serverId", serverId); put("kind", kind.name); put("title", title)
    put("poster", poster ?: ""); put("group", group); put("url", url)
    put("seriesId", seriesId ?: ""); put("seriesTitle", seriesTitle)
    put("season", season); put("episode", episode); put("rating", rating)
    put("plot", plot); put("ext", ext); put("resolve", resolve)
}.toString()

fun contentFromJson(s: String): Content {
    val o = JSONObject(s)
    return Content(
        key = o.getString("key"), serverId = o.getLong("serverId"),
        kind = Kind.valueOf(o.getString("kind")), title = o.getString("title"),
        poster = o.optString("poster").ifBlank { null }, group = o.optString("group"),
        url = o.optString("url"), seriesId = o.optString("seriesId").ifBlank { null },
        seriesTitle = o.optString("seriesTitle"), season = o.optInt("season"),
        episode = o.optInt("episode"), rating = o.optString("rating"),
        plot = o.optString("plot"), ext = o.optString("ext"), resolve = o.optBoolean("resolve")
    )
}

/** قراءة آمنة لحقل نصي (org.json يُرجع "null" للقيم الفارغة) */
internal fun JSONObject.str(k: String): String {
    val v = opt(k)
    return if (v == null || v == JSONObject.NULL) "" else v.toString()
}

internal inline fun JSONArray.forEachObj(f: (JSONObject) -> Unit) {
    for (i in 0 until length()) optJSONObject(i)?.let(f)
}
