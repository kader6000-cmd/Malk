package com.novaiptv.app.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.novaiptv.app.app
import com.novaiptv.app.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object Downloads {
    private const val QUEUE = "dl-queue"

    /** إضافة حلقة/فيلم/قائمة كاملة إلى طابور التحميل */
    suspend fun enqueue(ctx: Context, items: List<Content>) {
        val dao = ctx.app.db.downloads()
        var added = 0
        for (c in items) {
            if (c.kind == Kind.LIVE) continue
            val ex = dao.get(c.key)
            if (ex != null && ex.status == "DONE" && File(ex.filePath).exists()) continue
            if (ex != null && (ex.status == "QUEUED" || ex.status == "RUNNING")) continue
            dao.upsert(
                DownloadEntity(
                    contentKey = c.key,
                    serverId = c.serverId,
                    json = c.toJson(),
                    title = c.display,
                    filePath = ex?.filePath ?: "",
                    status = "QUEUED",
                    downloaded = ex?.downloaded ?: 0,
                    total = ex?.total ?: 0,
                    updatedAt = System.currentTimeMillis(),
                    error = ""
                )
            )
            added++
        }
        if (added > 0) {
            start(ctx)
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    ctx,
                    if (added == 1) "بدأ التحميل — راجع قسم مكتبتي" else "تمت إضافة $added عناصر إلى طابور التحميل",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun start(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(QUEUE, ExistingWorkPolicy.KEEP, req)
    }

    suspend fun retry(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().upsert(d.copy(status = "QUEUED", error = "", updatedAt = System.currentTimeMillis()))
        start(ctx)
    }

    suspend fun remove(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().remove(d.contentKey)
        withContext(Dispatchers.IO) { if (d.filePath.isNotBlank()) File(d.filePath).delete() }
    }
}

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo("جارٍ تجهيز التحميل…", 0, true)

    override suspend fun doWork(): Result {
        val dao = applicationContext.app.db.downloads()
        while (true) {
            val d = dao.nextPending() ?: break
            runCatching { setForeground(foregroundInfo(d.title, 0, true)) }
            try {
                process(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (dao.get(d.contentKey) != null) {
                    dao.upsert(
                        d.copy(
                            status = "FAILED",
                            error = e.message ?: "فشل التحميل",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
        return Result.success()
    }

    /**
     * تتبع التحويلات يدوياً (301/302/307/308) الخاصة بسيرفرات IPTV مثل tv.nv2.info و my8k
     * للحفاظ على التوكن والـ Headers عند الانتقال إلى سيرفر التخزين الفرعي (Load Balancer)
     */
    private fun openStreamWithRedirects(
        baseClient: OkHttpClient,
        initialUrl: String,
        userAgent: String,
        rangeStart: Long
    ): Pair<Response, Long> {
        val noRedirectClient = baseClient.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()

        val uas = listOf(userAgent.ifBlank { DEFAULT_UA }, PLAYER_UA, "VLC/3.0.20 LibVLC/3.0.20", DEFAULT_UA).distinct()
        var lastError = "تعذر الاتصال بالسيرفر"

        for (ua in uas) {
            try {
                var currentUrl = initialUrl
                var redirects = 0
                while (redirects < 10) {
                    val reqBuilder = Request.Builder()
                        .url(currentUrl)
                        .header("User-Agent", ua)
                        .header("Accept", "*/*")
                        .header("Connection", "keep-alive")
                    if (rangeStart > 0) {
                        reqBuilder.header("Range", "bytes=$rangeStart-")
                    } else {
                        reqBuilder.header("Range", "bytes=0-")
                    }

                    val resp = noRedirectClient.newCall(reqBuilder.build()).execute()
                    val code = resp.code

                    if (code in listOf(301, 302, 303, 307, 308)) {
                        val loc = resp.header("Location")
                        resp.close()
                        if (loc.isNullOrBlank()) break
                        currentUrl = if (loc.startsWith("http", true)) loc else {
                            val origin = Regex("^(https?://[^/]+)").find(currentUrl)?.groupValues?.get(1) ?: ""
                            if (loc.startsWith("/")) origin + loc else "$origin/$loc"
                        }
                        redirects++
                        continue
                    }

                    // إذا رفض السيرفر طلب الـ Range، نعيد المحاولة بدون Range
                    if ((code == 400 || code == 403 || code == 405 || code == 416 || code >= 500) && rangeStart > 0) {
                        resp.close()
                        val retryReq = Request.Builder()
                            .url(currentUrl)
                            .header("User-Agent", ua)
                            .header("Accept", "*/*")
                            .build()
                        val retryResp = noRedirectClient.newCall(retryReq).execute()
                        if (retryResp.isSuccessful) return retryResp to 0L
                        lastError = "HTTP ${retryResp.code}"
                        retryResp.close()
                        break
                    }

                    if (resp.isSuccessful) {
                        val ct = resp.header("Content-Type")?.lowercase() ?: ""
                        // التأكد من أن السيرفر لم يرجع صفحة خطأ HTML أو نص صغير بدل الفيديو
                        if (ct.contains("text/html") || ct.contains("application/json")) {
                            resp.close()
                            lastError = "السيرفر أرجع استجابة غير صالحة ($ct)"
                            break
                        }
                        val actualOffset = if (code == 206 && rangeStart > 0) rangeStart else 0L
                        return resp to actualOffset
                    } else {
                        lastError = "HTTP $code"
                        resp.close()
                        break
                    }
                }
            } catch (e: Exception) {
                lastError = e.message ?: "خطأ في الشبكة"
            }
        }
        throw IllegalStateException("تعذر التحميل من السيرفر ($lastError)")
    }

    private suspend fun process(d: DownloadEntity) {
        val app = applicationContext.app
        val dao = app.db.downloads()
        var c = contentFromJson(d.json)
        val server = app.db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")

        // جلب تفاصيل الفيلم من Xtream للتأكد من امتداد الملف الحقيقي (mp4 / mkv)
        if (c.kind == Kind.MOVIE && server.type == ServerType.XTREAM.name) {
            c = app.repo.movieDetails(server, c)
        }

        var url = app.repo.remoteUrl(c)
        // تنظيف منفذ 80 إن وجد في الروابط المحفوظة مسبقاً
        if (url.startsWith("http://", true) && url.contains(":80/")) {
            url = url.replaceFirst(":80/", "/")
        }

        if (url.contains(".m3u8", true)) {
            throw IllegalStateException("هذا المحتوى يعمل ببث متقطع (HLS) ولا يدعم التحميل المباشر")
        }

        val dir = File(applicationContext.getExternalFilesDir(null) ?: applicationContext.filesDir, "downloads").apply { mkdirs() }
        val baseFileName = c.key.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val initialExt = c.ext.ifBlank {
            url.substringBefore('?').substringAfterLast('.', "mp4").take(4).lowercase().ifBlank { "mp4" }
        }
        val file = File(dir, "$baseFileName.$initialExt")
        val existing = if (file.exists()) file.length() else 0L

        dao.upsert(d.copy(filePath = file.absolutePath, status = "RUNNING", error = "", updatedAt = System.currentTimeMillis()))

        withContext(Dispatchers.IO) {
            val (r, offset) = openStreamWithRedirects(
                baseClient = app.http.client,
                initialUrl = url,
                userAgent = server.userAgent.ifBlank { DEFAULT_UA },
                rangeStart = existing
            )
            r.use { resp ->
                val append = offset > 0L
                val body = resp.body ?: throw IllegalStateException("رد فارغ من السيرفر")
                val contentLength = body.contentLength()
                val total = if (contentLength > 0) contentLength + offset else 0L
                var done = offset
                var lastTick = 0L

                FileOutputStream(file, append).use { out ->
                    body.byteStream().use { ins ->
                        val buf = ByteArray(128 * 1024)
                        while (true) {
                            ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 750) {
                                lastTick = now
                                if (dao.get(d.contentKey) == null) {
                                    out.close()
                                    file.delete()
                                    return@withContext
                                }
                                dao.progress(d.contentKey, done, total, "RUNNING", now)
                                val p = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
                                runCatching { setForegroundAsync(foregroundInfo(d.title, p, total <= 0)) }
                            }
                        }
                    }
                }
            }
        }

        if (dao.get(d.contentKey) == null) return
        val size = file.length()
        if (size < 10_000L) {
            file.delete()
            throw IllegalStateException("الملف المحمّل صغير جداً أو غير مكتمل — قد يكون السيرفر يمنع تحميل هذا الفيلم")
        }

        // نسخ الملف إلى مجلد التنزيلات العام Downloads/NovaIPTV ليظهر في مدير الملفات والاستوديو أيضاً
        runCatching { exportToPublicDownloads(applicationContext, file, c.display, initialExt) }

        dao.progress(d.contentKey, size, size, "DONE", System.currentTimeMillis())
    }

    private fun exportToPublicDownloads(ctx: Context, srcFile: File, displayTitle: String, ext: String) {
        val cleanName = displayTitle.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { srcFile.nameWithoutExtension }
        val fileName = "$cleanName.$ext"
        val mime = when (ext.lowercase()) {
            "mkv" -> "video/x-matroska"
            "ts" -> "video/mp2t"
            else -> "video/mp4"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NovaIPTV")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(srcFile).use { ins -> ins.copyTo(out, 128 * 1024) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            val pubDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NovaIPTV").apply { mkdirs() }
            val dst = File(pubDir, fileName)
            srcFile.copyTo(dst, overwrite = true)
        }
    }

    private fun foregroundInfo(title: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val ch = "downloads"
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "التحميلات", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(applicationContext, ch)
            .setContentTitle(if (indeterminate) "جارٍ التحميل…" else "جارٍ التحميل ($progress%)")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, indeterminate)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1001, n)
    }
}
